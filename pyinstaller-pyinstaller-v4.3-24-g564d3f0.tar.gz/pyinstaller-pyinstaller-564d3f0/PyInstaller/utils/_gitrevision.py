#
# The content of this file will be filled in with meaningful data
# when creating an archive using `git archive` or by downloading an
# archive from github, e.g. from github.com/.../archive/develop.zip
#
rev = "564d3f0dd1"     # abbreviated commit hash
commit = "564d3f0dd1854582fc6581eb249ffd3669ac7963"  # commit hash
date = "2021-04-27 16:26:40 +0100"   # commit date
author = "bwoodsend <bwoodsend@gmail.com>"
ref_names = "HEAD -> develop"  # incl. current branch
commit_message = """Doc: Fix up version changed annotations.

These were written assuming the next feature release would be
5.0 but it turned out to be 4.3.
"""
